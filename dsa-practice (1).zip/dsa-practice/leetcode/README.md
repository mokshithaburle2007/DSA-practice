# LeetCode Solutions (Python 3)

**12 solved** - 10 Easy, 2 Medium, 0 Hard

| # | Problem | Difficulty | Topic | Solution |
|---|---------|------------|-------|----------|
| 1 | Two Sum | Easy | Array, Hash Table | [py](arrays/0001_two_sum.py) |
| 9 | Palindrome Number | Easy | Math | [py](math/0009_palindrome_number.py) |
| 27 | Remove Element | Easy | Two Pointers | [py](two-pointers/0027_remove_element.py) |
| 58 | Length of Last Word | Easy | String | [py](strings/0058_length_of_last_word.py) |
| 66 | Plus One | Easy | Array, Math | [py](math/0066_plus_one.py) |
| 69 | Sqrt(x) | Easy | Math, Binary Search | [py](math/0069_sqrtx.py) |
| 75 | Sort Colors | Medium | Two Pointers, Sorting | [py](sorting/0075_sort_colors.py) |
| 242 | Valid Anagram | Easy | Hash Table, String | [py](hashing/0242_valid_anagram.py) |
| 283 | Move Zeroes | Easy | Two Pointers | [py](two-pointers/0283_move_zeroes.py) |
| 344 | Reverse String | Easy | Two Pointers, String | [py](two-pointers/0344_reverse_string.py) |
| 643 | Maximum Average Subarray I | Easy | Sliding Window | [py](sliding-window/0643_maximum_average_subarray_i.py) |
| 1343 | Number of Sub-arrays of Size K and Average >= Threshold | Medium | Sliding Window | [py](sliding-window/1343_number_of_sub_arrays_of_size_k_and_average_greater_than_or_equal_to_threshold.py) |

## Up next
- [ ] 347. Top K Frequent Elements
- [ ] 217. Contains Duplicate
