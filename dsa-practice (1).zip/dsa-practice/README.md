# DSA Practice

My daily Data Structures & Algorithms practice in **Python 3**: class notes, small programs,
and LeetCode solutions.

## Structure

```
dsa-practice/
├── notes/            # daily class notes (markdown)
├── python-basics/    # small programs from class
├── leetcode/         # one file per problem, grouped by topic
└── templates/        # reusable patterns (sliding window, ...)
```

## Daily notes

| Day | Date | Topics |
|-----|------|--------|
| 1 | 05-10-2026 | Python basics, data types, operators, conditionals, loops, f-strings |
| 2 | 06-10-2026 | Leap year, list loops, dictionaries, frequency counting |
| 3 | 07-10-2026 | Valid Anagram, OOP concepts, classes and `self` |
| 4 | 08-10-2026 | Polymorphism, variable-length arguments, sliding window intro |
| 5 | 09-10-2026 | Sliding window steps, inheritance |

Notes live in [`notes/`](notes/).

## LeetCode progress

See [`leetcode/README.md`](leetcode/README.md) for the full table.

**12 solved** (10 Easy, 2 Medium, 0 Hard)

## Conventions

- File name: `NNNN_problem_name.py` (LeetCode number, zero-padded)
- Each file starts with the problem link, difficulty, approach and complexity
- Solutions use the LeetCode `class Solution` format

## Running a solution

```bash
python -m pytest        # if tests are added later
python leetcode/arrays/0001_two_sum.py
```
